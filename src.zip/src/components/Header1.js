import React from 'react';

export const Header1 = () => {
    return (
        <h2>
        Expense tracker
        </h2>
    )
}